package com.WIP.Ecomerce_SpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomerceSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomerceSpringBootApplication.class, args);
	}

}
